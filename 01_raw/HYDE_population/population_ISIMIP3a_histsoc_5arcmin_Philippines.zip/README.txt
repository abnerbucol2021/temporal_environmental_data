The following commands were used to create the files in this container:

ncks -O -h -d lon,118.000000,126.500000 -d lat,5.000000,17.000000 population_histsoc_5arcmin_annual_1850_1900.nc population_histsoc_5arcmin_annual_1850_1900_lon118.0to126.5lat5.0to17.0.nc
ncks -O -h -d lon,118.000000,126.500000 -d lat,5.000000,17.000000 population_histsoc_5arcmin_annual_1901_2021.nc population_histsoc_5arcmin_annual_1901_2021_lon118.0to126.5lat5.0to17.0.nc
