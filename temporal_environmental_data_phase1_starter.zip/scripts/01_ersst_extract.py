"""
Phase 1: NOAA ERSSTv5 extraction for Jolo, Masinloc, and Palapag.
Period: 1900-2018 inclusive.

IMPORTANT:
ERSSTv5 is a 2° x 2° Level-4 observation-based reconstructed SST product.
Because a 70-km buffer is smaller than the ERSST grid spacing, this script
uses the nearest ERSST ocean grid cell for each site and records the grid
center and site-to-grid-center distance. Do NOT describe these values as a
70-km spatial mean.

Outputs:
03_extracted/ersstv5_monthly_1900_2018.csv
03_extracted/ersstv5_annual_1900_2018.csv
04_tables/ersstv5_site_grid_provenance.csv
04_tables/ersstv5_trend_summary.csv
05_figures/Fig_ERSSTv5_SST_1900_2018.png
05_figures/Fig_ERSSTv5_SST_1900_2018.pdf
"""

from pathlib import Path
from urllib.request import urlretrieve
import math

import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
from scipy.stats import linregress

ROOT = Path(r"D:\temporal_environmental_data")
SITES_FILE = ROOT / "00_metadata" / "sites.csv"
RAW_DIR = ROOT / "01_raw" / "ERSST"
OUT_DIR = ROOT / "03_extracted"
TABLE_DIR = ROOT / "04_tables"
FIG_DIR = ROOT / "05_figures"
LOG_DIR = ROOT / "07_logs"

for d in [RAW_DIR, OUT_DIR, TABLE_DIR, FIG_DIR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

START_YEAR = 1900
END_YEAR = 2018

# NOAA PSL THREDDS HTTP fileServer copy of monthly ERSSTv5.
# The local cache avoids repeatedly querying the remote service.
DATA_URL = (
    "https://psl.noaa.gov/thredds/fileServer/"
    "Datasets/noaa.ersst.v5/sst.mnmean.nc"
)
NC_FILE = RAW_DIR / "sst.mnmean.nc"


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km."""
    R = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = (
        math.sin(dphi / 2) ** 2
        + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    )
    return 2 * R * math.asin(math.sqrt(a))


def to_360(lon):
    """Convert longitude to ERSST's 0..360 convention."""
    return lon % 360


print("=== ERSSTv5 Phase 1 ===")

if not SITES_FILE.exists():
    raise FileNotFoundError(
        f"{SITES_FILE} not found. Run scripts\\00_setup_project.py first."
    )

if not NC_FILE.exists():
    print("Downloading NOAA ERSSTv5 monthly NetCDF...")
    print(DATA_URL)
    urlretrieve(DATA_URL, NC_FILE)
    print(f"Saved: {NC_FILE}")
else:
    print(f"Using cached file: {NC_FILE}")

print("Opening NetCDF...")
ds = xr.open_dataset(NC_FILE)

required = {"sst", "lat", "lon", "time"}
missing = required.difference(ds.variables)
if missing:
    raise RuntimeError(f"Missing expected ERSST variables: {missing}")

# Restrict once to the requested time period.
sst = ds["sst"].sel(time=slice(f"{START_YEAR}-01-01", f"{END_YEAR}-12-31"))

sites = pd.read_csv(SITES_FILE)
monthly_frames = []
provenance_rows = []

for row in sites.itertuples(index=False):
    site = row.site
    site_lat = float(row.latitude)
    site_lon = float(row.longitude)
    site_lon_360 = to_360(site_lon)

    # Nearest grid-cell extraction is intentional because ERSST is 2°.
    point = sst.sel(lat=site_lat, lon=site_lon_360, method="nearest").load()

    grid_lat = float(point["lat"].values)
    grid_lon_360 = float(point["lon"].values)
    grid_lon_display = grid_lon_360 if grid_lon_360 <= 180 else grid_lon_360 - 360
    distance_km = haversine_km(site_lat, site_lon, grid_lat, grid_lon_display)

    df = point.to_dataframe(name="sst_degC").reset_index()
    df["site"] = site
    df["site_latitude"] = site_lat
    df["site_longitude"] = site_lon
    df["grid_latitude"] = grid_lat
    df["grid_longitude"] = grid_lon_display
    df["grid_center_distance_km"] = distance_km
    df["dataset"] = "NOAA ERSSTv5"
    df["variable"] = "sea_surface_temperature"
    df["unit"] = "degC"
    df["data_class"] = "observation_based_reconstruction"
    df["processing_level"] = "NOAA Level 4"
    df["spatial_resolution"] = "2 degree x 2 degree"
    df["spatial_extraction"] = "nearest_ocean_grid_cell"
    df["requested_buffer_km"] = 70
    df["buffer_applied"] = False
    df["source_basis"] = (
        "in_situ marine observations with statistical reconstruction; "
        "not a direct point observation"
    )
    monthly_frames.append(df)

    provenance_rows.append(
        {
            "site": site,
            "site_latitude": site_lat,
            "site_longitude": site_lon,
            "ersst_grid_latitude": grid_lat,
            "ersst_grid_longitude": grid_lon_display,
            "site_to_grid_center_km": distance_km,
            "requested_buffer_km": 70,
            "buffer_applied": False,
            "spatial_extraction": "nearest_ocean_grid_cell",
            "effective_spatial_support": "2 degree ERSST grid cell",
            "dataset": "NOAA ERSSTv5",
            "data_class": "observation_based_reconstruction",
            "processing_level": "NOAA Level 4",
            "period_used": f"{START_YEAR}-{END_YEAR}",
        }
    )

monthly = pd.concat(monthly_frames, ignore_index=True)
monthly["year"] = pd.to_datetime(monthly["time"]).dt.year
monthly["month"] = pd.to_datetime(monthly["time"]).dt.month

# Keep only useful fields in stable order.
monthly_cols = [
    "site", "site_latitude", "site_longitude",
    "year", "month", "time", "sst_degC",
    "grid_latitude", "grid_longitude", "grid_center_distance_km",
    "dataset", "variable", "unit", "data_class", "processing_level",
    "spatial_resolution", "spatial_extraction",
    "requested_buffer_km", "buffer_applied", "source_basis",
]
monthly = monthly[monthly_cols].sort_values(["site", "year", "month"])
monthly.to_csv(OUT_DIR / "ersstv5_monthly_1900_2018.csv", index=False)

# Annual summaries.
annual = (
    monthly.groupby(["site", "site_latitude", "site_longitude", "year"], as_index=False)
    .agg(
        sst_mean_degC=("sst_degC", "mean"),
        sst_sd_monthly_degC=("sst_degC", "std"),
        sst_min_monthly_degC=("sst_degC", "min"),
        sst_max_monthly_degC=("sst_degC", "max"),
        n_months=("sst_degC", "count"),
        grid_latitude=("grid_latitude", "first"),
        grid_longitude=("grid_longitude", "first"),
        grid_center_distance_km=("grid_center_distance_km", "first"),
    )
)

annual["sst_seasonal_range_degC"] = (
    annual["sst_max_monthly_degC"] - annual["sst_min_monthly_degC"]
)
annual["dataset"] = "NOAA ERSSTv5"
annual["data_class"] = "observation_based_reconstruction"
annual["spatial_extraction"] = "nearest_ocean_grid_cell"
annual["requested_buffer_km"] = 70
annual["buffer_applied"] = False

annual.to_csv(OUT_DIR / "ersstv5_annual_1900_2018.csv", index=False)

provenance = pd.DataFrame(provenance_rows)
provenance.to_csv(TABLE_DIR / "ersstv5_site_grid_provenance.csv", index=False)

# Linear trend summary. More robust Mann-Kendall/Sen statistics are added
# in the later unified trend-analysis phase.
trend_rows = []
for site, g in annual.groupby("site"):
    g = g.dropna(subset=["sst_mean_degC"])
    lr = linregress(g["year"], g["sst_mean_degC"])

    trend_rows.append(
        {
            "site": site,
            "variable": "annual_mean_SST",
            "dataset": "NOAA ERSSTv5",
            "data_class": "observation_based_reconstruction",
            "period": f"{START_YEAR}-{END_YEAR}",
            "n_years": len(g),
            "slope_degC_per_year": lr.slope,
            "slope_degC_per_decade": lr.slope * 10,
            "intercept": lr.intercept,
            "r_squared": lr.rvalue ** 2,
            "p_value": lr.pvalue,
            "stderr_slope_per_year": lr.stderr,
        }
    )

trend = pd.DataFrame(trend_rows)
trend.to_csv(TABLE_DIR / "ersstv5_trend_summary.csv", index=False)

# Publication-style figure: annual values + centered 10-year rolling mean.
fig, ax = plt.subplots(figsize=(10, 6))

for site, g in annual.groupby("site", sort=False):
    g = g.sort_values("year").copy()
    g["sst_roll10"] = g["sst_mean_degC"].rolling(
        window=10, center=True, min_periods=5
    ).mean()

    line, = ax.plot(
        g["year"],
        g["sst_mean_degC"],
        linewidth=0.8,
        alpha=0.35,
        label=f"{site} annual",
    )
    ax.plot(
        g["year"],
        g["sst_roll10"],
        linewidth=2.2,
        label=f"{site} 10-y mean",
        color=line.get_color(),
    )

ax.axvline(1940, linestyle="--", linewidth=1)
ax.text(
    1941,
    ax.get_ylim()[0] + 0.05,
    "Early ERSST period:\ninterpret with greater caution",
    fontsize=8,
    va="bottom",
)

ax.set_title("Sea-surface temperature trajectories at three Philippine locations")
ax.set_xlabel("Year")
ax.set_ylabel("Sea-surface temperature (°C)")
ax.set_xlim(START_YEAR, END_YEAR)
ax.legend(frameon=False, ncol=2, fontsize=8)
ax.grid(alpha=0.2)
fig.tight_layout()

fig.savefig(FIG_DIR / "Fig_ERSSTv5_SST_1900_2018.png", dpi=600, bbox_inches="tight")
fig.savefig(FIG_DIR / "Fig_ERSSTv5_SST_1900_2018.pdf", bbox_inches="tight")
plt.close(fig)

ds.close()

print("\nDONE.")
print(f"Monthly:    {OUT_DIR / 'ersstv5_monthly_1900_2018.csv'}")
print(f"Annual:     {OUT_DIR / 'ersstv5_annual_1900_2018.csv'}")
print(f"Provenance: {TABLE_DIR / 'ersstv5_site_grid_provenance.csv'}")
print(f"Trends:     {TABLE_DIR / 'ersstv5_trend_summary.csv'}")
print(f"Figure PNG: {FIG_DIR / 'Fig_ERSSTv5_SST_1900_2018.png'}")
print(f"Figure PDF: {FIG_DIR / 'Fig_ERSSTv5_SST_1900_2018.pdf'}")
